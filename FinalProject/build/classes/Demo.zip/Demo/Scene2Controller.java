/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Demo;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Vothana CHY
 */
public class Scene2Controller implements Initializable {

    @FXML
    private Label txtFromSence1;
    @FXML
    private TextField txtBox;
    @FXML
    private Button btnGoBacks;

    String text;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        btnGoBacks.setText(" I am scene 2" );
    }    
    
    @FXML
    private void goBack(ActionEvent event) {
        final Node source = (Node) event.getSource();
        final Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
        text = txtBox.getText();
    }
    
    public String getText(){
        return text;
    }
    
    public void setText(String text){
        txtFromSence1.setText(text);
    }
}
