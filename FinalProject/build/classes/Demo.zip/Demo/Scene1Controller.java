/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Demo;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;

/**
 * FXML Controller class
 *
 * @author Vothana CHY
 */
public class Scene1Controller implements Initializable {

    @FXML
    private Button btnGoToScene2;
    @FXML
    private Label txtInput;
    
    Window owner;
    Stage primaryStage;
    Scene scene ;
    Parent root;
    FXMLLoader loader;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void gotoScene2(ActionEvent event) throws IOException {
        owner = btnGoToScene2.getScene().getWindow();
        loader = new FXMLLoader(getClass().getResource("Scene2.fxml"));
        root = loader.load();
        scene = new Scene(root);
        scene.setFill(Color.TRANSPARENT);
        primaryStage = new Stage();
        primaryStage.setResizable(false);
        primaryStage.initOwner(owner);
        primaryStage.setScene(scene);
        primaryStage.focusedProperty();
        primaryStage.initModality(Modality.WINDOW_MODAL);
        primaryStage.initStyle(StageStyle.TRANSPARENT);
        
        Scene2Controller controller = loader.getController();
        controller.setText("My name is KOKO");
        
        
        primaryStage.show();
        
        txtInput.setText(controller.getText());
        
        System.out.println("Hello HEllo");
    }
    
}
